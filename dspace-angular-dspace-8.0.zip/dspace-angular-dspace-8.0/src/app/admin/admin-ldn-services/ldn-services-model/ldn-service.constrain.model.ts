export class LdnServiceConstrain {
  void: any;
}
