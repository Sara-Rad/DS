/**
 * List of services statuses
 */
export enum LdnServiceStatus {
  UNKOWN,
  DISABLED,
  ENABLED,
}
