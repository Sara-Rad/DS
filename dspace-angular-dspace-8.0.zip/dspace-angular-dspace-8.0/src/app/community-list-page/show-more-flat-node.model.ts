/**
 * The show more links in the community tree are also represented by a flatNode so we know where in
 *  the tree it should be rendered and who its parent is (needed for the action resulting in clicking this link)
 */
export class ShowMoreFlatNode {
}
